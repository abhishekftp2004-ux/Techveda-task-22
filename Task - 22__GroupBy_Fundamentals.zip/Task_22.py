"""
Task 22: GroupBy Fundamentals — Ultra Expanded
Requires: Python 3.9+ and Pandas
Keep this script beside superstore_groupby_sample.csv, then run: python Task_22.py
"""
import pandas as pd

df = pd.read_csv("superstore_groupby_sample.csv")

print("1. PREVIEW")
print(df.head())
print("\nShape:", df.shape)
print("\nData types:\n", df.dtypes)

# 1) SUM: total sales by region
sales_by_region = df.groupby("Region")["Sales"].sum().sort_values(ascending=False)
print("\n2. Total sales by region\n", sales_by_region)

# 2) MEAN: average profit by category
avg_profit_by_category = df.groupby("Category")["Profit"].mean().round(2)
print("\n3. Average profit by category\n", avg_profit_by_category)

# 3) COUNT: non-missing Order_ID values by segment
records_by_segment = df.groupby("Segment")["Order_ID"].count()
print("\n4. Records by segment\n", records_by_segment)

# 4) MIN/MAX: sales range by category
sales_min_max = df.groupby("Category")["Sales"].agg(["min", "max"])
print("\n5. Minimum and maximum sales by category\n", sales_min_max)

# 5) Multiple aggregation: regional scorecard
region_summary = df.groupby("Region").agg(
    Total_Sales=("Sales", "sum"),
    Average_Sales=("Sales", "mean"),
    Total_Profit=("Profit", "sum"),
    Record_Count=("Order_ID", "count"),
    Total_Quantity=("Quantity", "sum"),
    Average_Discount=("Discount", "mean")
).round(2)
print("\n6. Regional scorecard\n", region_summary)

# 6) Group by two columns
region_category_sales = df.groupby(["Region", "Category"])["Sales"].sum()
print("\n7. Sales by region and category\n", region_category_sales.sort_values(ascending=False))

# 7) Unique values
unique_categories = df.groupby("Region")["Category"].nunique()
print("\n8. Unique categories per region\n", unique_categories)

# 8) Several statistics for profit
profit_stats = df.groupby("Category")["Profit"].agg(["sum", "mean", "count", "min", "max"]).round(2)
print("\n9. Profit statistics by category\n", profit_stats)

# 9) Compare size() and count()
print("\n10. Row count by region (size)\n", df.groupby("Region").size())
print("\n11. Non-missing Order_ID count by region\n", df.groupby("Region")["Order_ID"].count())

# 10) Filter groups after aggregation
large_sales_regions = region_summary[region_summary["Total_Sales"] > region_summary["Total_Sales"].median()]
print("\n12. Regions above median total sales\n", large_sales_regions)

# Save outputs
region_summary.to_csv("region_groupby_summary.csv")
profit_stats.to_csv("category_profit_summary.csv")
region_category_sales.rename("Total_Sales").to_csv("region_category_sales_summary.csv")
print("\nSummary CSV files saved.")
